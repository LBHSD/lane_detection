from setuptools import find_packages, setup

package_name = 'emb_24_package'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='lbhhh',
    maintainer_email='lbhhh@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'lane_detection_node = emb_24_package.lane_detection_node:main',
            'my_subscriber = emb_24_package.my_subscriber:main',
            'my_publisher = emb_24_package.my_publisher:main',
            'turtle_cmd_and_pose = emb_24_package.turtle_cmd_and_pose:main'
        ],
    },
)
