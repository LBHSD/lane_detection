def main():
    print('Hi from emb_24_package.')


if __name__ == '__main__':
    main()
