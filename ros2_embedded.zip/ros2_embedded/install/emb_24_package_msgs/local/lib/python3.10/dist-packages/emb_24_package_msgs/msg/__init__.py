from emb_24_package_msgs.msg._cmd_and_pose_vel import CmdAndPoseVel  # noqa: F401
