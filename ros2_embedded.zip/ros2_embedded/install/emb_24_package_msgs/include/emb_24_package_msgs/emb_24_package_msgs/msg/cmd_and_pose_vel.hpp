// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EMB_24_PACKAGE_MSGS__MSG__CMD_AND_POSE_VEL_HPP_
#define EMB_24_PACKAGE_MSGS__MSG__CMD_AND_POSE_VEL_HPP_

#include "emb_24_package_msgs/msg/detail/cmd_and_pose_vel__struct.hpp"
#include "emb_24_package_msgs/msg/detail/cmd_and_pose_vel__builder.hpp"
#include "emb_24_package_msgs/msg/detail/cmd_and_pose_vel__traits.hpp"

#endif  // EMB_24_PACKAGE_MSGS__MSG__CMD_AND_POSE_VEL_HPP_
