// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from lane_detection_msgs:msg/LaneDetection.idl
// generated code does not contain a copyright notice

#ifndef LANE_DETECTION_MSGS__MSG__DETAIL__LANE_DETECTION__BUILDER_HPP_
#define LANE_DETECTION_MSGS__MSG__DETAIL__LANE_DETECTION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "lane_detection_msgs/msg/detail/lane_detection__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace lane_detection_msgs
{

namespace msg
{

namespace builder
{

class Init_LaneDetection_direction_dev
{
public:
  explicit Init_LaneDetection_direction_dev(::lane_detection_msgs::msg::LaneDetection & msg)
  : msg_(msg)
  {}
  ::lane_detection_msgs::msg::LaneDetection direction_dev(::lane_detection_msgs::msg::LaneDetection::_direction_dev_type arg)
  {
    msg_.direction_dev = std::move(arg);
    return std::move(msg_);
  }

private:
  ::lane_detection_msgs::msg::LaneDetection msg_;
};

class Init_LaneDetection_deviation
{
public:
  explicit Init_LaneDetection_deviation(::lane_detection_msgs::msg::LaneDetection & msg)
  : msg_(msg)
  {}
  Init_LaneDetection_direction_dev deviation(::lane_detection_msgs::msg::LaneDetection::_deviation_type arg)
  {
    msg_.deviation = std::move(arg);
    return Init_LaneDetection_direction_dev(msg_);
  }

private:
  ::lane_detection_msgs::msg::LaneDetection msg_;
};

class Init_LaneDetection_curve_direction
{
public:
  explicit Init_LaneDetection_curve_direction(::lane_detection_msgs::msg::LaneDetection & msg)
  : msg_(msg)
  {}
  Init_LaneDetection_deviation curve_direction(::lane_detection_msgs::msg::LaneDetection::_curve_direction_type arg)
  {
    msg_.curve_direction = std::move(arg);
    return Init_LaneDetection_deviation(msg_);
  }

private:
  ::lane_detection_msgs::msg::LaneDetection msg_;
};

class Init_LaneDetection_curve_radius
{
public:
  Init_LaneDetection_curve_radius()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LaneDetection_curve_direction curve_radius(::lane_detection_msgs::msg::LaneDetection::_curve_radius_type arg)
  {
    msg_.curve_radius = std::move(arg);
    return Init_LaneDetection_curve_direction(msg_);
  }

private:
  ::lane_detection_msgs::msg::LaneDetection msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::lane_detection_msgs::msg::LaneDetection>()
{
  return lane_detection_msgs::msg::builder::Init_LaneDetection_curve_radius();
}

}  // namespace lane_detection_msgs

#endif  // LANE_DETECTION_MSGS__MSG__DETAIL__LANE_DETECTION__BUILDER_HPP_
