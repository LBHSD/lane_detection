﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from lane_detection_msgs:msg/LaneDetection.idl
// generated code does not contain a copyright notice

#ifndef LANE_DETECTION_MSGS__MSG__DETAIL__LANE_DETECTION__STRUCT_H_
#define LANE_DETECTION_MSGS__MSG__DETAIL__LANE_DETECTION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'curve_direction'
// Member 'direction_dev'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/LaneDetection in the package lane_detection_msgs.
typedef struct lane_detection_msgs__msg__LaneDetection
{
  /// 차선 곡률 반경 (미터)
  double curve_radius;
  /// 곡선 방향 ('Left Curve', 'Right Curve', 'Straight')
  rosidl_runtime_c__String curve_direction;
  /// 차선 중앙으로부터의 편차 (미터)
  double deviation;
  /// 편차 방향 ('left', 'right', 'center')
  rosidl_runtime_c__String direction_dev;
} lane_detection_msgs__msg__LaneDetection;

// Struct for a sequence of lane_detection_msgs__msg__LaneDetection.
typedef struct lane_detection_msgs__msg__LaneDetection__Sequence
{
  lane_detection_msgs__msg__LaneDetection * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} lane_detection_msgs__msg__LaneDetection__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // LANE_DETECTION_MSGS__MSG__DETAIL__LANE_DETECTION__STRUCT_H_
