// generated from rosidl_generator_c/resource/idl.h.em
// with input from lane_detection_msgs:msg/LaneDetection.idl
// generated code does not contain a copyright notice

#ifndef LANE_DETECTION_MSGS__MSG__LANE_DETECTION_H_
#define LANE_DETECTION_MSGS__MSG__LANE_DETECTION_H_

#include "lane_detection_msgs/msg/detail/lane_detection__struct.h"
#include "lane_detection_msgs/msg/detail/lane_detection__functions.h"
#include "lane_detection_msgs/msg/detail/lane_detection__type_support.h"

#endif  // LANE_DETECTION_MSGS__MSG__LANE_DETECTION_H_
