// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LANE_DETECTION_MSGS__MSG__LANE_DETECTION_HPP_
#define LANE_DETECTION_MSGS__MSG__LANE_DETECTION_HPP_

#include "lane_detection_msgs/msg/detail/lane_detection__struct.hpp"
#include "lane_detection_msgs/msg/detail/lane_detection__builder.hpp"
#include "lane_detection_msgs/msg/detail/lane_detection__traits.hpp"

#endif  // LANE_DETECTION_MSGS__MSG__LANE_DETECTION_HPP_
