#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from lane_detection_msgs.msg import LaneDetection

class LaneDetectionSubscriber(Node):
    def __init__(self):
        super().__init__('lane_detection_subscriber')
        self.subscription = self.create_subscription(
            LaneDetection,
            'lane_detection_info',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning

    def listener_callback(self, msg):
        self.get_logger().info(f'Received lane detection info:')
        self.get_logger().info(f'  Curve Radius: {msg.curve_radius:.2f}m')
        self.get_logger().info(f'  Curve Direction: {msg.curve_direction}')
        self.get_logger().info(f'  Deviation: {msg.deviation:.3f}m to the {msg.direction_dev}')

def main(args=None):
    rclpy.init(args=args)
    lane_detection_subscriber = LaneDetectionSubscriber()
    rclpy.spin(lane_detection_subscriber)
    lane_detection_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
